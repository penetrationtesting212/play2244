"""
Test Enhanced Playwright Script Analyzer
Tests all new active intelligence features
"""

import json
from script_analyzer import PlaywrightScriptAnalyzer

# Comprehensive test script with all features from play.md
comprehensive_test_script = """
import { test, expect } from '@playwright/test';
import testData from './data/users.json';
import { LoginPage } from './pages/LoginPage';

test.describe('Banking Application Tests', () => {
    test.beforeEach(async ({ page }) => {
        await page.goto('https://bank.example.com/login');
    });
    
    test.afterEach(async ({ page }) => {
        await page.click('#logout-btn');
    });
    
    test.setTimeout(30000);
    
    test('Complete banking workflow with all locator types', async ({ page }) => {
        // Modern locators (EXCELLENT quality)
        await page.getByRole('textbox', { name: 'Username' }).fill('john.doe');
        await page.getByLabel('Email').fill('john@example.com');
        await page.getByPlaceholder('Enter password').fill('SecurePass123!');
        await page.getByTestId('login-button').click();
        
        // Wait for navigation
        await page.waitForURL('**/dashboard');
        await expect(page.getByRole('heading', { name: 'Dashboard' })).toBeVisible();
        
        // Legacy CSS selectors (FAIR quality)
        await page.fill('#transfer-amount', '1000.50');
        await page.fill('[data-testid="recipient-account"]', 'GB82WEST12345698765432');
        await page.selectOption('#account-type', 'savings');
        
        // XPath selectors (POOR/UNSTABLE quality - should trigger recommendations)
        await page.locator('xpath=/html/body/div[1]/div[2]/form/button[1]').click();
        await page.locator('xpath=//div[@id="confirmation"]//button[@class="confirm-btn"]').click();
        
        // Dynamic class (UNSTABLE - should trigger warning)
        await page.click('.btn-a7f3d8');
        
        // Assertions
        await expect(page.locator('.success-message')).toBeVisible();
        await expect(page.locator('.success-message')).toHaveText('Transfer successful');
        await expect(page).toHaveURL(/transfer-complete/);
        
        // Keyboard interaction
        await page.press('#search-box', 'Enter');
        
        // File upload
        await page.setInputFiles('#document-upload', 'test-file.pdf');
        
        // Hover action
        await page.hover('#help-tooltip');
        
        // Screenshot
        await page.screenshot({ path: 'transfer-complete.png' });
    });
    
    test('Data-driven test with external API', async ({ request, page }) => {
        // API call (should detect API_HYBRID pattern)
        const response = await request.get('https://api.example.com/test-users');
        const users = await response.json();
        
        await page.goto('https://bank.example.com/register');
        await page.fill('#username', users[0].username);
        await page.fill('#email', users[0].email);
    });
});

// Page Object Model (should detect POM pattern)
class TransferPage {
    constructor(page) {
        this.page = page;
        this.amountInput = page.locator('#amount');
        this.recipientInput = page.locator('#recipient');
    }
    
    async performTransfer(amount, recipient) {
        await this.amountInput.fill(amount);
        await this.recipientInput.fill(recipient);
    }
}

// Component testing (should detect COMPONENT pattern)
test.describe('Component Tests', () => {
    test('login form validation', async ({ mount }) => {
        const component = await mount(<LoginForm />);
        await component.getByRole('button', { name: 'Submit' }).click();
        await expect(component.getByText('Email is required')).toBeVisible();
    });
});
"""

print("="*80)
print("ENHANCED PLAYWRIGHT SCRIPT ANALYZER - COMPREHENSIVE TEST")
print("="*80)

analyzer = PlaywrightScriptAnalyzer()
analysis = analyzer.analyze(comprehensive_test_script)

print("\n📊 ANALYSIS SUMMARY")
print("-"*80)
print(json.dumps(analysis.summary, indent=2))

print("\n🎯 QUALITY SCORE")
print("-"*80)
print(f"Overall Quality Score: {analysis.quality_score}/100")

print("\n🔍 DETECTED TEST PATTERN")
print("-"*80)
print(f"Pattern: {analysis.detected_pattern.value if analysis.detected_pattern else 'None'}")

print("\n📍 INPUT FIELDS DETECTED")
print("-"*80)
print(f"Total: {len(analysis.input_fields)}")
for i, field in enumerate(analysis.input_fields[:10], 1):
    print(f"{i}. {field.field_name} ({field.field_type.value}) - Line {field.line_number}")
    print(f"   Selector: {field.selector}")

print("\n⚡ ACTIONS DETECTED")
print("-"*80)
print(f"Total: {len(analysis.actions)}")
quality_counts = {}
for action in analysis.actions:
    if action.quality:
        quality_counts[action.quality.value] = quality_counts.get(action.quality.value, 0) + 1

print(f"\nLocator Quality Distribution:")
for quality, count in sorted(quality_counts.items()):
    print(f"  {quality}: {count}")

print("\n🛡️ XPATH ANALYSIS")
print("-"*80)
print(f"Total XPath selectors: {len(analysis.xpath_analysis)}")
for i, xpath_item in enumerate(analysis.xpath_analysis, 1):
    print(f"\n{i}. Line {xpath_item.line_number}")
    print(f"   Type: {xpath_item.xpath_type.value}")
    print(f"   XPath: {xpath_item.xpath[:60]}...")
    print(f"   Complexity Score: {xpath_item.complexity_score}/100")
    print(f"   Stability Score: {xpath_item.stability_score}/100")
    if xpath_item.issues:
        print(f"   Issues: {', '.join(xpath_item.issues)}")
    if xpath_item.recommended_alternative:
        print(f"   ✅ Recommendation: {xpath_item.recommended_alternative}")

print("\n📂 EXTERNAL DATA SOURCES")
print("-"*80)
print(f"Total: {len(analysis.external_data_sources)}")
for i, source in enumerate(analysis.external_data_sources, 1):
    print(f"{i}. Type: {source.source_type}")
    if source.file_path:
        print(f"   File: {source.file_path}")
    if source.api_endpoint:
        print(f"   API: {source.api_endpoint}")
    print(f"   Line: {source.line_number}")

print("\n🧪 TEST CONTEXT")
print("-"*80)
if analysis.test_context:
    print(f"Test Name: {analysis.test_context.test_name or 'N/A'}")
    print(f"Description: {analysis.test_context.description or 'N/A'}")
    print(f"Has Hooks: {analysis.test_context.has_hooks}")
    print(f"Timeout: {analysis.test_context.timeout or 'default'} ms")
    print(f"Retries: {analysis.test_context.retries or 'default'}")
    print(f"Fixtures: {', '.join(analysis.test_context.fixtures) if analysis.test_context.fixtures else 'None'}")

print("\n✅ ASSERTIONS")
print("-"*80)
print(f"Total: {len(analysis.assertions)}")
for i, assertion in enumerate(analysis.assertions[:10], 1):
    print(f"{i}. Type: {assertion['type']} - Line {assertion['line_number']}")
    if assertion.get('expected_value'):
        print(f"   Expected: {assertion['expected_value']}")

print("\n💡 PROACTIVE RECOMMENDATIONS")
print("-"*80)
print(f"Total: {len(analysis.recommendations)}")
for i, rec in enumerate(analysis.recommendations, 1):
    priority_icon = "🔴" if rec['priority'] == 'high' else "🟡" if rec['priority'] == 'medium' else "🟢"
    print(f"\n{i}. {priority_icon} [{rec['priority'].upper()}] {rec['title']}")
    print(f"   Category: {rec['category']}")
    print(f"   Description: {rec['description']}")
    print(f"   Suggestion: {rec['suggestion']}")
    if rec.get('issues'):
        print(f"   Issues: {', '.join(rec['issues'])}")

print("\n🔧 TEST DATA GENERATION RECOMMENDATIONS")
print("-"*80)
recommendations = analyzer.generate_test_data_recommendations(analysis)
print(f"Security Tests: {len(recommendations['security_tests'])}")
print(f"Boundary Tests: {len(recommendations['boundary_tests'])}")
print(f"Equivalence Tests: {len(recommendations['equivalence_tests'])}")

print("\n" + "="*80)
print("✅ ENHANCED ANALYZER TEST COMPLETE!")
print("="*80)
print(f"\nKey Metrics:")
print(f"  - Quality Score: {analysis.quality_score}/100")
print(f"  - Pattern: {analysis.detected_pattern.value if analysis.detected_pattern else 'basic'}")
print(f"  - Input Fields: {len(analysis.input_fields)}")
print(f"  - Actions: {len(analysis.actions)}")
print(f"  - XPath Issues: {len(analysis.xpath_analysis)}")
print(f"  - Recommendations: {len(analysis.recommendations)}")
print(f"  - Modern Locators: {analysis.summary.get('locator_quality', {}).get('excellent', 0)}")
print(f"  - External Data Sources: {len(analysis.external_data_sources)}")
