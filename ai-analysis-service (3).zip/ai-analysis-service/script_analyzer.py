"""
Enhanced Playwright Script Analyzer - Active Intelligence Mode
Comprehensive analysis of Playwright test scripts with proactive recommendations.

Extracts and Analyzes:
- Input fields (all modern + legacy locators)
- Actions (click, navigate, wait, keyboard, mouse, scroll)
- Assertions and expected outcomes
- Field types with intelligent constraints
- External data sources (JSON, CSV, Excel, API)
- Test patterns (POM, Fixtures, Data-Driven)
- XPath analysis (type, complexity, stability)
- Test context (descriptions, tags, timeouts, retries)
- Interaction patterns (keyboard combos, mouse gestures)
- Script quality metrics with proactive recommendations

Used for:
- Automated test data generation (security, boundary, equivalence)
- Test quality assessment and improvement
- Self-healing locator recommendations
- Test maintenance optimization
"""

import re
import json
import os
from typing import List, Dict, Any, Optional, Tuple, Set
from dataclasses import dataclass, asdict, field
from enum import Enum
from pathlib import Path


class FieldType(str, Enum):
    TEXT = "text"
    NUMBER = "number"
    EMAIL = "email"
    PASSWORD = "password"
    TEL = "tel"
    URL = "url"
    SEARCH = "search"
    DATE = "date"
    TEXTAREA = "textarea"
    SELECT = "select"
    CHECKBOX = "checkbox"
    RADIO = "radio"


class ActionType(str, Enum):
    FILL = "fill"
    TYPE = "type"
    CLICK = "click"
    SELECT_OPTION = "selectOption"
    CHECK = "check"
    UNCHECK = "uncheck"
    NAVIGATE = "goto"
    WAIT = "waitFor"
    PRESS = "press"
    HOVER = "hover"
    DRAG = "drag"
    SCROLL = "scroll"
    SCREENSHOT = "screenshot"
    UPLOAD = "setInputFiles"
    DOUBLE_CLICK = "dblclick"
    RIGHT_CLICK = "contextMenu"


class XPathType(str, Enum):
    ABSOLUTE = "absolute"  # /html/body/div[1]
    RELATIVE = "relative"  # //button[@id='submit']
    PREFIXED = "prefixed"  # xpath=//div


class LocatorQuality(str, Enum):
    EXCELLENT = "excellent"  # Role-based, label-based
    GOOD = "good"           # Test IDs, stable attributes
    FAIR = "fair"           # CSS selectors with semantic meaning
    POOR = "poor"           # Generic classes, XPath
    UNSTABLE = "unstable"   # Dynamic IDs, absolute XPath


class TestPattern(str, Enum):
    BASIC = "basic"
    PAGE_OBJECT = "page_object_model"
    FIXTURE = "fixture_based"
    DATA_DRIVEN = "data_driven"
    API_HYBRID = "api_hybrid"
    COMPONENT = "component_testing"


@dataclass
class InputField:
    selector: str
    field_type: FieldType
    field_name: str
    action: ActionType
    line_number: int
    example_value: Optional[str] = None
    min_length: Optional[int] = None
    max_length: Optional[int] = None
    pattern: Optional[str] = None
    required: bool = True
    constraints: Optional[Dict[str, Any]] = None


@dataclass
class ScriptAction:
    action_type: ActionType
    target: str
    value: Optional[str] = None
    line_number: int = 0
    quality: Optional[LocatorQuality] = None
    recommendation: Optional[str] = None


@dataclass
class XPathAnalysis:
    xpath: str
    xpath_type: XPathType
    complexity_score: int  # 0-100
    stability_score: int   # 0-100
    recommended_alternative: Optional[str] = None
    issues: List[str] = field(default_factory=list)
    line_number: int = 0


@dataclass
class ExternalDataSource:
    source_type: str  # 'json', 'csv', 'excel', 'api'
    file_path: Optional[str] = None
    api_endpoint: Optional[str] = None
    line_number: int = 0
    fields: List[str] = field(default_factory=list)


@dataclass
class TestContext:
    test_name: Optional[str] = None
    description: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    timeout: Optional[int] = None
    retries: Optional[int] = None
    browser_config: Optional[Dict[str, Any]] = None
    fixtures: List[str] = field(default_factory=list)
    has_hooks: bool = False


@dataclass
class InteractionPattern:
    pattern_type: str  # 'keyboard_combo', 'mouse_gesture', 'scroll_sequence'
    actions: List[str] = field(default_factory=list)
    complexity: str = "simple"  # simple, moderate, complex
    line_number: int = 0


@dataclass
class ScriptAnalysis:
    input_fields: List[InputField]
    actions: List[ScriptAction]
    navigation_url: Optional[str] = None
    assertions: List[Dict[str, Any]] = field(default_factory=list)
    summary: Dict[str, Any] = field(default_factory=dict)
    
    # Enhanced analysis data
    xpath_analysis: List[XPathAnalysis] = field(default_factory=list)
    external_data_sources: List[ExternalDataSource] = field(default_factory=list)
    test_context: Optional[TestContext] = None
    interaction_patterns: List[InteractionPattern] = field(default_factory=list)
    detected_pattern: Optional[TestPattern] = None
    quality_score: int = 0  # 0-100
    recommendations: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self):
        return {
            'input_fields': [asdict(f) for f in self.input_fields],
            'actions': [asdict(a) for a in self.actions],
            'navigation_url': self.navigation_url,
            'assertions': self.assertions,
            'summary': self.summary,
            'xpath_analysis': [asdict(x) for x in self.xpath_analysis],
            'external_data_sources': [asdict(d) for d in self.external_data_sources],
            'test_context': asdict(self.test_context) if self.test_context else None,
            'interaction_patterns': [asdict(p) for p in self.interaction_patterns],
            'detected_pattern': self.detected_pattern.value if self.detected_pattern else None,
            'quality_score': self.quality_score,
            'recommendations': self.recommendations
        }


class PlaywrightScriptAnalyzer:
    """Enhanced Playwright Script Analyzer with Active Intelligence"""

    # Regex patterns for ALL Playwright commands + enhanced patterns
    PATTERNS = {
        # Navigation
        'goto': r'(?:page|context)\.goto\([\'"]([^\'"]+)[\'"]',
        
        # Legacy locator methods (page.fill, page.click)
        'fill': r'(?:page|locator)\.fill\([\'"]([^\'"]+)[\'"],\s*[\'"]([^\'"]*)[\'"]',
        'type': r'(?:page|locator)\.type\([\'"]([^\'"]+)[\'"],\s*[\'"]([^\'"]*)[\'"]',
        'click': r'(?:page|locator)\.click\([\'"]([^\'"]+)[\'"]',
        'press': r'(?:page|locator)\.press\([\'"]([^\'"]+)[\'"],\s*[\'"]([^\'"]*)[\'"]',
        'selectOption': r'(?:page|locator)\.selectOption\([\'"]([^\'"]+)[\'"],\s*[\'"]?([^\'"]*)[\'"]?',
        'check': r'(?:page|locator)\.check\([\'"]([^\'"]+)[\'"]',
        'uncheck': r'(?:page|locator)\.uncheck\([\'"]([^\'"]+)[\'"]',
        
        # Enhanced interaction patterns
        'hover': r'(?:page|locator)\.hover\([\'"]?([^\'"\)]+)?[\'"]?\)',
        'dblclick': r'(?:page|locator)\.dblclick\([\'"]([^\'"]+)[\'"]',
        'dragAndDrop': r'(?:page|locator)\.dragAndDrop\([\'"]([^\'"]+)[\'"],\s*[\'"]([^\'"]+)[\'"]',
        'setInputFiles': r'(?:page|locator)\.setInputFiles\([\'"]([^\'"]+)[\'"],\s*[\'"]([^\'"]+)[\'"]',
        'screenshot': r'(?:page|locator)\.screenshot\(',
        'scroll': r'(?:page|locator)\.scroll(?:IntoView)?',
        
        # Modern Playwright locators (getBy* methods)
        'getByRole': r'(?:page|locator)\.getByRole\([\'"]([^\'"]+)[\'"](?:,\s*\{[^}]*name:\s*[\'"]([^\'"]+)[\'"])?',
        'getByLabel': r'(?:page|locator)\.getByLabel\([\'"]([^\'"]+)[\'"]',
        'getByPlaceholder': r'(?:page|locator)\.getByPlaceholder\([\'"]([^\'"]+)[\'"]',
        'getByText': r'(?:page|locator)\.getByText\([\'"]([^\'"]+)[\'"]',
        'getByTestId': r'(?:page|locator)\.getByTestId\([\'"]([^\'"]+)[\'"]',
        'getByAltText': r'(?:page|locator)\.getByAltText\([\'"]([^\'"]+)[\'"]',
        'getByTitle': r'(?:page|locator)\.getByTitle\([\'"]([^\'"]+)[\'"]',
        
        # Chained locators
        'locator': r'(?:page|locator)\.locator\([\'"]([^\'"]+)[\'"]',
        'first': r'\.first\(\)',
        'last': r'\.last\(\)',
        'nth': r'\.nth\((\d+)\)',
        'filter': r'\.filter\(\{[^}]*hasText:\s*[\'"]([^\'"]+)[\'"]',
        
        # Wait methods
        'waitFor': r'(?:page|locator)\.waitFor(?:Selector)?\([\'"]([^\'"]+)[\'"]',
        'waitForLoadState': r'page\.waitForLoadState\([\'"]?([^\'"\)]*)[\'"]?\)',
        'waitForTimeout': r'page\.waitForTimeout\((\d+)\)',
        'waitForURL': r'page\.waitForURL\([\'"]?([^\'"\)]+)?[\'"]?\)',
        
        # Assertions
        'expect': r'expect\(([^)]+)\)',
        'toBeVisible': r'\.toBeVisible\(\)',
        'toHaveText': r'\.toHaveText\([\'"]([^\'"]+)[\'"]',
        'toHaveValue': r'\.toHaveValue\([\'"]([^\'"]+)[\'"]',
        'toBeChecked': r'\.toBeChecked\(\)',
        'toHaveURL': r'\.toHaveURL\([\'"]?([^\'"\)]+)?[\'"]?\)',
        'toContainText': r'\.toContainText\([\'"]([^\'"]+)[\'"]',
        
        # XPath selectors (all variations)
        'xpath_absolute': r'xpath=(/html[^\'"]*)[\'"]',
        'xpath_relative': r'xpath=(//[^\'"]*)[\'"]',
        'xpath_inline': r'[\'"]xpath=([^\'"]*)[\'"]',
        
        # CSS selectors
        'css_id': r'#([a-zA-Z][a-zA-Z0-9_-]*)',
        'css_class': r'\.([a-zA-Z][a-zA-Z0-9_-]*)',
        'css_attr': r'\[([a-zA-Z-]+)=[\'"]([^\'"]+)[\'"]\]',
        
        # External data sources
        'json_import': r'import\s+.*from\s+[\'"]([^\'"]*\.json)[\'"]',
        'csv_import': r'import\s+.*from\s+[\'"]([^\'"]*\.csv)[\'"]',
        'excel_import': r'xlsx\.readFile\([\'"]([^\'"]+\.xlsx)[\'"]',
        'api_call': r'(?:await\s+)?(?:request|axios|fetch)\.(?:get|post|put|delete)\([\'"]([^\'"]+)[\'"]',
        'require_json': r'require\([\'"]([^\'"]*\.json)[\'"]\)',
        'readFile': r'readFile(?:Sync)?\([\'"]([^\'"]+)[\'"]',
        
        # Test patterns
        'test_describe': r'test\.describe\([\'"]([^\'"]+)[\'"]',
        'test_name': r'test\([\'"]([^\'"]+)[\'"]',
        'beforeEach': r'test\.beforeEach',
        'afterEach': r'test\.afterEach',
        'beforeAll': r'test\.beforeAll',
        'afterAll': r'test\.afterAll',
        'fixture_extend': r'test\.extend',
        'page_object_class': r'class\s+(\w+)(?:Page|Component)',
        'mount_component': r'mount\(<(\w+)',
        'test_use': r'test\.use\(',
        'test_timeout': r'test\.setTimeout\((\d+)\)',
        'test_retries': r'test\.(?:describe\.)?configure\(\{\s*retries:\s*(\d+)',
    }

    def analyze(self, script_code: str) -> ScriptAnalysis:
        """
        Enhanced analysis of Playwright script with active intelligence
        Extracts ALL testable elements, patterns, and provides proactive recommendations
        """
        input_fields = []
        actions = []
        navigation_url = None
        assertions = []
        xpath_analysis = []
        external_data_sources = []
        interaction_patterns = []
        
        # Test context tracking
        test_context = TestContext()
        
        # Pattern detection
        has_page_object = False
        has_fixtures = False
        has_data_driven = False
        has_api_hybrid = False
        has_component = False
        
        lines = script_code.split('\n')

        for line_num, line in enumerate(lines, start=1):
            line_stripped = line.strip()

            # === EXTRACT TEST CONTEXT ===
            
            # Test description/name
            test_desc_match = re.search(self.PATTERNS['test_describe'], line_stripped)
            if test_desc_match:
                test_context.description = test_desc_match.group(1)
            
            test_name_match = re.search(self.PATTERNS['test_name'], line_stripped)
            if test_name_match and not test_context.test_name:
                test_context.test_name = test_name_match.group(1)
            
            # Test hooks
            if re.search(self.PATTERNS['beforeEach'], line_stripped) or re.search(self.PATTERNS['afterEach'], line_stripped):
                test_context.has_hooks = True
            
            # Timeout configuration
            timeout_match = re.search(self.PATTERNS['test_timeout'], line_stripped)
            if timeout_match:
                test_context.timeout = int(timeout_match.group(1))
            
            # Retry configuration
            retries_match = re.search(self.PATTERNS['test_retries'], line_stripped)
            if retries_match:
                test_context.retries = int(retries_match.group(1))
            
            # Fixture detection
            if re.search(self.PATTERNS['fixture_extend'], line_stripped):
                has_fixtures = True
                test_context.fixtures.append('custom_fixture')
            
            if re.search(self.PATTERNS['test_use'], line_stripped):
                has_fixtures = True
            
            # === DETECT TEST PATTERNS ===
            
            # Page Object Model
            pom_match = re.search(self.PATTERNS['page_object_class'], line_stripped)
            if pom_match:
                has_page_object = True
            
            # Component testing
            component_match = re.search(self.PATTERNS['mount_component'], line_stripped)
            if component_match:
                has_component = True
            
            # === EXTRACT EXTERNAL DATA SOURCES ===
            
            # JSON files
            json_match = re.search(self.PATTERNS['json_import'], line_stripped)
            if not json_match:
                json_match = re.search(self.PATTERNS['require_json'], line_stripped)
            if json_match:
                has_data_driven = True
                external_data_sources.append(ExternalDataSource(
                    source_type='json',
                    file_path=json_match.group(1),
                    line_number=line_num
                ))
            
            # CSV files
            csv_match = re.search(self.PATTERNS['csv_import'], line_stripped)
            if csv_match:
                has_data_driven = True
                external_data_sources.append(ExternalDataSource(
                    source_type='csv',
                    file_path=csv_match.group(1),
                    line_number=line_num
                ))
            
            # Excel files
            excel_match = re.search(self.PATTERNS['excel_import'], line_stripped)
            if excel_match:
                has_data_driven = True
                external_data_sources.append(ExternalDataSource(
                    source_type='excel',
                    file_path=excel_match.group(1),
                    line_number=line_num
                ))
            
            # API calls
            api_match = re.search(self.PATTERNS['api_call'], line_stripped)
            if api_match:
                has_api_hybrid = True
                external_data_sources.append(ExternalDataSource(
                    source_type='api',
                    api_endpoint=api_match.group(1),
                    line_number=line_num
                ))
            
            # === XPATH DEEP ANALYSIS ===
            
            # Absolute XPath
            xpath_abs_match = re.search(self.PATTERNS['xpath_absolute'], line_stripped)
            if xpath_abs_match:
                xpath = xpath_abs_match.group(1)
                analysis = self._analyze_xpath(xpath, XPathType.ABSOLUTE, line_num)
                xpath_analysis.append(analysis)
            
            # Relative XPath
            xpath_rel_match = re.search(self.PATTERNS['xpath_relative'], line_stripped)
            if xpath_rel_match:
                xpath = xpath_rel_match.group(1)
                analysis = self._analyze_xpath(xpath, XPathType.RELATIVE, line_num)
                xpath_analysis.append(analysis)

            # Extract navigation URL
            if not navigation_url:
                goto_match = re.search(self.PATTERNS['goto'], line_stripped)
                if goto_match:
                    navigation_url = goto_match.group(1)
                    actions.append(ScriptAction(
                        action_type=ActionType.NAVIGATE,
                        target=navigation_url,
                        line_number=line_num,
                        quality=LocatorQuality.EXCELLENT
                    ))

            # ===== MODERN PLAYWRIGHT LOCATORS (getBy* methods) =====
            
            # getByRole - Most recommended by Playwright
            role_match = re.search(self.PATTERNS['getByRole'], line_stripped)
            if role_match:
                role = role_match.group(1)
                name = role_match.group(2) if len(role_match.groups()) > 1 else None
                selector = f"getByRole('{role}', {{ name: '{name}' }})"
                
                # Determine action type
                action_type = self._detect_action_from_line(line_stripped)
                if action_type in [ActionType.FILL, ActionType.TYPE, ActionType.CHECK]:
                    field_type, field_name, constraints = self._detect_field_from_role(role, name)
                    input_fields.append(InputField(
                        selector=selector,
                        field_type=field_type,
                        field_name=field_name or name or role,
                        action=action_type,
                        line_number=line_num,
                        **constraints
                    ))
                
                actions.append(ScriptAction(
                    action_type=action_type or ActionType.CLICK,
                    target=selector,
                    line_number=line_num,
                    quality=LocatorQuality.EXCELLENT,
                    recommendation="✅ Excellent: Role-based locators are Playwright's recommended approach"
                ))
            
            # getByLabel
            label_match = re.search(self.PATTERNS['getByLabel'], line_stripped)
            if label_match:
                label_text = label_match.group(1)
                selector = f"getByLabel('{label_text}')"
                action_type = self._detect_action_from_line(line_stripped)
                
                if action_type in [ActionType.FILL, ActionType.TYPE]:
                    field_type, field_name, constraints = self._detect_field_info(label_text, '')
                    input_fields.append(InputField(
                        selector=selector,
                        field_type=field_type,
                        field_name=field_name or label_text,
                        action=action_type,
                        line_number=line_num,
                        **constraints
                    ))
                
                actions.append(ScriptAction(
                    action_type=action_type or ActionType.CLICK,
                    target=selector,
                    line_number=line_num,
                    quality=LocatorQuality.EXCELLENT
                ))
            
            # getByPlaceholder
            placeholder_match = re.search(self.PATTERNS['getByPlaceholder'], line_stripped)
            if placeholder_match:
                placeholder = placeholder_match.group(1)
                selector = f"getByPlaceholder('{placeholder}')"
                action_type = self._detect_action_from_line(line_stripped)
                
                if action_type in [ActionType.FILL, ActionType.TYPE]:
                    field_type, field_name, constraints = self._detect_field_info(placeholder, '')
                    input_fields.append(InputField(
                        selector=selector,
                        field_type=field_type,
                        field_name=field_name or placeholder,
                        action=action_type,
                        line_number=line_num,
                        **constraints
                    ))
                
                actions.append(ScriptAction(
                    action_type=action_type or ActionType.CLICK,
                    target=selector,
                    line_number=line_num,
                    quality=LocatorQuality.EXCELLENT
                ))
            
            # getByTestId
            testid_match = re.search(self.PATTERNS['getByTestId'], line_stripped)
            if testid_match:
                test_id = testid_match.group(1)
                selector = f"getByTestId('{test_id}')"
                action_type = self._detect_action_from_line(line_stripped)
                
                if action_type in [ActionType.FILL, ActionType.TYPE, ActionType.CHECK]:
                    field_type, field_name, constraints = self._detect_field_info(test_id, '')
                    input_fields.append(InputField(
                        selector=selector,
                        field_type=field_type,
                        field_name=field_name or test_id,
                        action=action_type,
                        line_number=line_num,
                        **constraints
                    ))
                
                actions.append(ScriptAction(
                    action_type=action_type or ActionType.CLICK,
                    target=selector,
                    line_number=line_num,
                    quality=LocatorQuality.GOOD
                ))
            
            # getByText
            text_match = re.search(self.PATTERNS['getByText'], line_stripped)
            if text_match and '.click()' in line_stripped:
                text = text_match.group(1)
                actions.append(ScriptAction(
                    action_type=ActionType.CLICK,
                    target=f"getByText('{text}')",
                    line_number=line_num,
                    quality=LocatorQuality.GOOD
                ))

            # ===== LEGACY LOCATOR METHODS =====
            
            # Extract fill actions
            fill_match = re.search(self.PATTERNS['fill'], line_stripped)
            if fill_match:
                selector = fill_match.group(1)
                value = fill_match.group(2) if len(fill_match.groups()) > 1 else ""
                
                field_type, field_name, constraints = self._detect_field_info(selector, value)
                
                input_fields.append(InputField(
                    selector=selector,
                    field_type=field_type,
                    field_name=field_name,
                    action=ActionType.FILL,
                    line_number=line_num,
                    example_value=value,
                    **constraints
                ))

                # Assess locator quality
                quality = self._assess_locator_quality(selector)
                actions.append(ScriptAction(
                    action_type=ActionType.FILL,
                    target=selector,
                    value=value,
                    line_number=line_num,
                    quality=quality
                ))

            # Extract type actions
            type_match = re.search(self.PATTERNS['type'], line_stripped)
            if type_match:
                selector = type_match.group(1)
                value = type_match.group(2) if len(type_match.groups()) > 1 else ""
                
                field_type, field_name, constraints = self._detect_field_info(selector, value)
                
                input_fields.append(InputField(
                    selector=selector,
                    field_type=field_type,
                    field_name=field_name,
                    action=ActionType.TYPE,
                    line_number=line_num,
                    example_value=value,
                    **constraints
                ))
                
                quality = self._assess_locator_quality(selector)
                actions.append(ScriptAction(
                    action_type=ActionType.TYPE,
                    target=selector,
                    value=value,
                    line_number=line_num,
                    quality=quality
                ))
            
            # Extract press actions (for keyboard events)
            press_match = re.search(self.PATTERNS['press'], line_stripped)
            if press_match:
                selector = press_match.group(1)
                key = press_match.group(2) if len(press_match.groups()) > 1 else ""
                actions.append(ScriptAction(
                    action_type=ActionType.PRESS,
                    target=selector,
                    value=f"press:{key}",
                    line_number=line_num,
                    quality=self._assess_locator_quality(selector)
                ))

            # Extract click actions
            click_match = re.search(self.PATTERNS['click'], line_stripped)
            if click_match:
                selector = click_match.group(1)
                actions.append(ScriptAction(
                    action_type=ActionType.CLICK,
                    target=selector,
                    line_number=line_num,
                    quality=self._assess_locator_quality(selector)
                ))

            # Extract selectOption actions
            select_match = re.search(self.PATTERNS['selectOption'], line_stripped)
            if select_match:
                selector = select_match.group(1)
                value = select_match.group(2) if len(select_match.groups()) > 1 else ""
                
                input_fields.append(InputField(
                    selector=selector,
                    field_type=FieldType.SELECT,
                    field_name=self._extract_field_name(selector),
                    action=ActionType.SELECT_OPTION,
                    line_number=line_num,
                    example_value=value
                ))
                
                actions.append(ScriptAction(
                    action_type=ActionType.SELECT_OPTION,
                    target=selector,
                    value=value,
                    line_number=line_num,
                    quality=self._assess_locator_quality(selector)
                ))

            # Extract check/uncheck actions
            check_match = re.search(self.PATTERNS['check'], line_stripped)
            if check_match:
                selector = check_match.group(1)
                input_fields.append(InputField(
                    selector=selector,
                    field_type=FieldType.CHECKBOX,
                    field_name=self._extract_field_name(selector),
                    action=ActionType.CHECK,
                    line_number=line_num
                ))
                
                actions.append(ScriptAction(
                    action_type=ActionType.CHECK,
                    target=selector,
                    line_number=line_num,
                    quality=self._assess_locator_quality(selector)
                ))

            # Extract assertions
            expect_match = re.search(self.PATTERNS['expect'], line_stripped)
            if expect_match:
                assertion_type = 'unknown'
                expected_value = None
                
                # Detect assertion type
                if 'toBeVisible' in line_stripped:
                    assertion_type = 'visibility'
                elif 'toHaveText' in line_stripped:
                    assertion_type = 'text_content'
                    text_match = re.search(self.PATTERNS['toHaveText'], line_stripped)
                    if text_match:
                        expected_value = text_match.group(1)
                elif 'toHaveValue' in line_stripped:
                    assertion_type = 'value'
                    value_match = re.search(self.PATTERNS['toHaveValue'], line_stripped)
                    if value_match:
                        expected_value = value_match.group(1)
                elif 'toHaveURL' in line_stripped:
                    assertion_type = 'url'
                    url_match = re.search(self.PATTERNS['toHaveURL'], line_stripped)
                    if url_match:
                        expected_value = url_match.group(1)
                
                assertions.append({
                    'type': assertion_type,
                    'target': expect_match.group(1),
                    'expected_value': expected_value,
                    'full_line': line_stripped,
                    'line_number': line_num
                })

        # === DETERMINE TEST PATTERN ===
        detected_pattern = TestPattern.BASIC
        if has_component:
            detected_pattern = TestPattern.COMPONENT
        elif has_page_object:
            detected_pattern = TestPattern.PAGE_OBJECT
        elif has_fixtures:
            detected_pattern = TestPattern.FIXTURE
        elif has_data_driven:
            detected_pattern = TestPattern.DATA_DRIVEN
        elif has_api_hybrid:
            detected_pattern = TestPattern.API_HYBRID
        
        # === GENERATE ENHANCED SUMMARY ===
        detected_fields = list(set([f.field_name for f in input_fields]))
        field_types = {}
        for field in input_fields:
            field_types[field.field_type.value] = field_types.get(field.field_type.value, 0) + 1

        summary = {
            'total_inputs': len(input_fields),
            'total_actions': len(actions),
            'has_validation': len(assertions) > 0,
            'detected_fields': detected_fields,
            'field_type_distribution': field_types,
            'navigation_url': navigation_url,
            'lines_analyzed': len(lines),
            'modern_locators_used': any('getBy' in str(f.selector) for f in input_fields),
            'xpath_used': len(xpath_analysis) > 0,
            'xpath_count': len(xpath_analysis),
            'external_data_sources': len(external_data_sources),
            'test_pattern': detected_pattern.value if detected_pattern else 'basic',
            'has_hooks': test_context.has_hooks if test_context else False,
            'locator_quality': {
                'excellent': sum(1 for a in actions if a.quality == LocatorQuality.EXCELLENT),
                'good': sum(1 for a in actions if a.quality == LocatorQuality.GOOD),
                'fair': sum(1 for a in actions if a.quality == LocatorQuality.FAIR),
                'poor': sum(1 for a in actions if a.quality == LocatorQuality.POOR),
                'unstable': sum(1 for a in actions if a.quality == LocatorQuality.UNSTABLE),
            }
        }
        
        # === CREATE ANALYSIS OBJECT ===
        analysis = ScriptAnalysis(
            input_fields=input_fields,
            actions=actions,
            navigation_url=navigation_url,
            assertions=assertions,
            summary=summary,
            xpath_analysis=xpath_analysis,
            external_data_sources=external_data_sources,
            test_context=test_context,
            interaction_patterns=interaction_patterns,
            detected_pattern=detected_pattern
        )
        
        # === CALCULATE QUALITY SCORE ===
        analysis.quality_score = self._calculate_quality_score(analysis)
        
        # === GENERATE PROACTIVE RECOMMENDATIONS ===
        analysis.recommendations = self._generate_recommendations(analysis)

        return analysis

    def _detect_field_info(self, selector: str, value: str = "") -> Tuple[FieldType, str, Dict]:
        """
        Detect field type, name, and constraints based on selector and value
        """
        lower_selector = selector.lower()
        field_name = self._extract_field_name(selector)
        constraints = {}

        # Email detection
        if 'email' in lower_selector or 'mail' in lower_selector:
            constraints = {
                'pattern': r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$',
                'max_length': 254
            }
            return FieldType.EMAIL, field_name, constraints

        # Password detection
        if 'password' in lower_selector or 'pwd' in lower_selector or 'pass' in lower_selector:
            constraints = {
                'min_length': 8,
                'max_length': 128
            }
            return FieldType.PASSWORD, field_name, constraints

        # Phone/Tel detection
        if 'phone' in lower_selector or 'tel' in lower_selector or 'mobile' in lower_selector:
            constraints = {
                'min_length': 10,
                'max_length': 15,
                'pattern': r'^[0-9+\-\s()]+$'
            }
            return FieldType.TEL, field_name, constraints

        # Number/Amount detection (Banking specific)
        if any(keyword in lower_selector for keyword in ['amount', 'quantity', 'price', 'age', 'number', 'balance', 'transfer']):
            constraints = {
                'min_length': 1,
                'max_length': 15,
                'pattern': r'^[0-9]+(\.[0-9]{1,2})?$'
            }
            return FieldType.NUMBER, field_name, constraints

        # Date detection
        if 'date' in lower_selector or 'birth' in lower_selector or 'dob' in lower_selector:
            return FieldType.DATE, field_name, constraints

        # URL detection
        if 'url' in lower_selector or 'website' in lower_selector or 'link' in lower_selector:
            constraints = {
                'pattern': r'^https?://[^\s]+$'
            }
            return FieldType.URL, field_name, constraints

        # Search detection
        if 'search' in lower_selector or 'query' in lower_selector:
            return FieldType.SEARCH, field_name, constraints

        # Textarea detection
        if any(keyword in lower_selector for keyword in ['textarea', 'comment', 'description', 'message', 'notes']):
            constraints = {
                'max_length': 5000
            }
            return FieldType.TEXTAREA, field_name, constraints

        # Default to text
        return FieldType.TEXT, field_name, constraints

    def _extract_field_name(self, selector: str) -> str:
        """
        Extract meaningful field name from selector
        Examples:
        - #username -> Username
        - [name="email"] -> Email
        - .input-password -> Password
        - input[data-testid="transfer-amount"] -> Transfer Amount
        """
        # Remove common prefixes and clean up
        name = selector
        name = re.sub(r'^[#.\[]', '', name)  # Remove leading #, ., [
        name = re.sub(r'[\'"\]].*$', '', name)  # Remove trailing quotes and brackets
        name = re.sub(r'name=', '', name)
        name = re.sub(r'id=', '', name)
        name = re.sub(r'data-testid=', '', name)
        name = re.sub(r'[-_]', ' ', name)  # Replace - and _ with space
        name = name.strip()

        # Capitalize words
        name = ' '.join(word.capitalize() for word in name.split())

        return name if name else 'Input Field'
    
    def _detect_action_from_line(self, line: str) -> Optional[ActionType]:
        """
        Detect what action is being performed on the line
        """
        if '.fill(' in line:
            return ActionType.FILL
        elif '.type(' in line:
            return ActionType.TYPE
        elif '.check(' in line:
            return ActionType.CHECK
        elif '.uncheck(' in line:
            return ActionType.UNCHECK
        elif '.click(' in line:
            return ActionType.CLICK
        elif '.selectOption(' in line:
            return ActionType.SELECT_OPTION
        elif '.hover(' in line:
            return ActionType.HOVER
        elif '.press(' in line:
            return ActionType.PRESS
        return None
    
    def _assess_locator_quality(self, selector: str) -> LocatorQuality:
        """
        Assess the quality and stability of a locator
        """
        selector_lower = selector.lower()
        
        # Test ID selectors are good
        if 'data-testid' in selector_lower or 'data-test-id' in selector_lower:
            return LocatorQuality.GOOD
        
        # ARIA attributes are good
        if 'aria-label' in selector_lower or 'role=' in selector_lower:
            return LocatorQuality.GOOD
        
        # Stable ID selectors (non-dynamic)
        if selector.startswith('#') and not re.search(r'#\w+-\d{6,}', selector):
            return LocatorQuality.FAIR
        
        # Dynamic-looking IDs or classes
        if re.search(r'[#.]\w+-[a-f0-9]{6,}', selector) or re.search(r'[#.]\w+-\d{6,}', selector):
            return LocatorQuality.UNSTABLE
        
        # XPath selectors
        if 'xpath=' in selector or selector.startswith('//'):
            if selector.count('/') > 5:  # Deep XPath
                return LocatorQuality.POOR
            elif re.search(r'\[\d+\]', selector):  # Positional
                return LocatorQuality.UNSTABLE
            return LocatorQuality.POOR
        
        # Generic class selectors
        if selector.startswith('.') and not any(semantic in selector_lower for semantic in ['btn', 'button', 'input', 'form', 'nav', 'header']):
            return LocatorQuality.FAIR
        
        # Semantic selectors
        if any(semantic in selector_lower for semantic in ['name=', 'placeholder=', 'type=', 'title=']):
            return LocatorQuality.FAIR
        
        return LocatorQuality.FAIR
    
    def _detect_field_from_role(self, role: str, name: Optional[str]) -> Tuple[FieldType, str, Dict]:
        """
        Detect field type from ARIA role
        """
        constraints = {}
        
        role_lower = role.lower()
        name_lower = name.lower() if name else ''
        
        # Map ARIA roles to field types
        if role_lower in ['textbox', 'searchbox']:
            if 'email' in name_lower:
                return FieldType.EMAIL, name or 'Email', {'pattern': r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', 'max_length': 254}
            elif 'password' in name_lower:
                return FieldType.PASSWORD, name or 'Password', {'min_length': 8, 'max_length': 128}
            elif 'search' in name_lower or role_lower == 'searchbox':
                return FieldType.SEARCH, name or 'Search', {}
            else:
                return FieldType.TEXT, name or 'Text Input', {}
        
        elif role_lower == 'checkbox':
            return FieldType.CHECKBOX, name or 'Checkbox', {}
        
        elif role_lower == 'radio':
            return FieldType.RADIO, name or 'Radio', {}
        
        elif role_lower == 'combobox' or role_lower == 'listbox':
            return FieldType.SELECT, name or 'Select', {}
        
        elif role_lower == 'spinbutton':
            return FieldType.NUMBER, name or 'Number', {}
        
        # Default to text for input-like roles
        return FieldType.TEXT, name or role, constraints
    
    def _analyze_xpath(self, xpath: str, xpath_type: XPathType, line_number: int) -> XPathAnalysis:
        """
        Deep analysis of XPath selector
        Returns complexity score, stability score, and recommendations
        """
        issues = []
        complexity_score = 0
        stability_score = 100
        recommended_alternative = None
        
        # Complexity Analysis
        # Count predicates (brackets)
        predicate_count = xpath.count('[')
        complexity_score += predicate_count * 10
        
        # Count hierarchy levels (/)
        level_count = xpath.count('/')
        complexity_score += level_count * 5
        
        # Absolute XPath is more complex
        if xpath_type == XPathType.ABSOLUTE:
            complexity_score += 30
            stability_score -= 40
            issues.append("Absolute XPath is brittle - breaks easily with DOM changes")
            recommended_alternative = "Use getByRole(), getByLabel(), or getByTestId() instead"
        
        # Stability Analysis
        # Check for positional selectors [1], [2], etc.
        if re.search(r'\[\d+\]', xpath):
            stability_score -= 30
            issues.append("Positional selectors (e.g., [1]) are unstable")
        
        # Check for generic tag names
        if re.search(r'//(div|span|p|a)(?![\w])', xpath):
            stability_score -= 20
            issues.append("Generic tags (div, span) without attributes are unstable")
        
        # Check for dynamic-looking attributes
        if re.search(r'@id=[\'"]\w*-\d+', xpath) or re.search(r'@class=[\'"]\w*-\w{6,}', xpath):
            stability_score -= 25
            issues.append("Appears to use dynamic IDs or classes")
        
        # Check for good practices
        if '@data-testid' in xpath or '@aria-label' in xpath:
            stability_score += 20
            complexity_score -= 10
        
        # Cap scores
        complexity_score = min(100, max(0, complexity_score))
        stability_score = min(100, max(0, stability_score))
        
        return XPathAnalysis(
            xpath=xpath,
            xpath_type=xpath_type,
            complexity_score=complexity_score,
            stability_score=stability_score,
            recommended_alternative=recommended_alternative,
            issues=issues,
            line_number=line_number
        )
    
    def _calculate_quality_score(self, analysis: ScriptAnalysis) -> int:
        """
        Calculate overall script quality score (0-100)
        Based on locator quality, test patterns, and best practices
        """
        score = 50  # Base score
        
        # Bonus for modern locators
        modern_locator_count = sum(1 for a in analysis.actions if a.quality == LocatorQuality.EXCELLENT)
        if analysis.actions:
            modern_ratio = modern_locator_count / len(analysis.actions)
            score += int(modern_ratio * 20)
        
        # Penalty for XPath usage
        if analysis.xpath_analysis:
            avg_xpath_stability = sum(x.stability_score for x in analysis.xpath_analysis) / len(analysis.xpath_analysis)
            score -= int((100 - avg_xpath_stability) / 5)
        
        # Bonus for test patterns
        if analysis.detected_pattern == TestPattern.PAGE_OBJECT:
            score += 10
        if analysis.detected_pattern == TestPattern.FIXTURE:
            score += 8
        if analysis.detected_pattern == TestPattern.DATA_DRIVEN:
            score += 12
        
        # Bonus for assertions
        if analysis.assertions:
            score += min(10, len(analysis.assertions) * 2)
        
        # Bonus for test context
        if analysis.test_context:
            if analysis.test_context.has_hooks:
                score += 5
            if analysis.test_context.timeout:
                score += 3
            if analysis.test_context.retries:
                score += 3
        
        return min(100, max(0, score))
    
    def _generate_recommendations(self, analysis: ScriptAnalysis) -> List[Dict[str, Any]]:
        """
        Generate proactive recommendations for script improvement
        """
        recommendations = []
        
        # XPath recommendations
        if analysis.xpath_analysis:
            for xpath_item in analysis.xpath_analysis:
                if xpath_item.stability_score < 60:
                    recommendations.append({
                        'priority': 'high',
                        'category': 'locator_stability',
                        'title': f'Unstable XPath detected (line {xpath_item.line_number})',
                        'description': f"XPath '{xpath_item.xpath[:50]}...' has low stability score ({xpath_item.stability_score}/100)",
                        'suggestion': xpath_item.recommended_alternative or 'Consider using role-based or test-id locators',
                        'issues': xpath_item.issues
                    })
        
        # Modern locator recommendation
        poor_locators = [a for a in analysis.actions if a.quality in [LocatorQuality.POOR, LocatorQuality.UNSTABLE]]
        if len(poor_locators) > 3:
            recommendations.append({
                'priority': 'medium',
                'category': 'modern_locators',
                'title': f'{len(poor_locators)} locators could be improved',
                'description': 'Several locators are using legacy or unstable selectors',
                'suggestion': 'Migrate to modern Playwright locators: getByRole(), getByLabel(), getByPlaceholder()'
            })
        
        # Missing assertions
        if not analysis.assertions:
            recommendations.append({
                'priority': 'high',
                'category': 'test_quality',
                'title': 'No assertions detected',
                'description': 'Test should include explicit assertions to validate expected behavior',
                'suggestion': 'Add expect() assertions to verify outcomes: toBeVisible(), toHaveText(), toHaveURL()'
            })
        
        # Missing test hooks
        if analysis.test_context and not analysis.test_context.has_hooks:
            recommendations.append({
                'priority': 'low',
                'category': 'test_structure',
                'title': 'Consider using test hooks',
                'description': 'beforeEach/afterEach hooks can improve test maintainability',
                'suggestion': 'Use beforeEach() for common setup and afterEach() for cleanup'
            })
        
        # External data recommendation
        if not analysis.external_data_sources and len(analysis.input_fields) > 5:
            recommendations.append({
                'priority': 'medium',
                'category': 'data_driven',
                'title': 'Consider data-driven testing',
                'description': f'{len(analysis.input_fields)} input fields detected with hardcoded values',
                'suggestion': 'Extract test data to JSON/CSV files for better maintainability and coverage'
            })
        
        # Pattern recommendation
        if not analysis.detected_pattern or analysis.detected_pattern == TestPattern.BASIC:
            if len(analysis.input_fields) > 10:
                recommendations.append({
                    'priority': 'medium',
                    'category': 'test_pattern',
                    'title': 'Consider Page Object Model',
                    'description': 'Large test script could benefit from POM pattern',
                    'suggestion': 'Refactor into Page Objects to improve reusability and maintenance'
                })
        
        return recommendations

    def generate_test_data_recommendations(self, analysis: ScriptAnalysis) -> Dict[str, Any]:
        """
        Generate test data recommendations based on script analysis
        """
        recommendations = {
            'security_tests': [],
            'boundary_tests': [],
            'equivalence_tests': []
        }

        for field in analysis.input_fields:
            # Security test recommendations
            if field.field_type in [FieldType.TEXT, FieldType.EMAIL, FieldType.PASSWORD, FieldType.TEXTAREA]:
                recommendations['security_tests'].append({
                    'field': field.selector,
                    'field_name': field.field_name,
                    'test_types': ['sql_injection', 'xss_attack', 'command_injection'],
                    'priority': 'high' if field.field_type == FieldType.PASSWORD else 'medium'
                })

            # Boundary value test recommendations
            if field.field_type == FieldType.NUMBER:
                recommendations['boundary_tests'].append({
                    'field': field.selector,
                    'field_name': field.field_name,
                    'field_type': 'number',
                    'min_value': 0,
                    'max_value': 999999.99 if 'amount' in field.field_name.lower() else 100,
                    'test_values': ['min', 'min-1', 'min+1', 'max', 'max+1', 'max-1', 'zero', 'negative']
                })

            if field.field_type in [FieldType.TEXT, FieldType.EMAIL]:
                recommendations['boundary_tests'].append({
                    'field': field.selector,
                    'field_name': field.field_name,
                    'field_type': 'string',
                    'min_length': field.min_length or 1,
                    'max_length': field.max_length or 255,
                    'test_values': ['min_length', 'max_length', 'empty', 'too_long']
                })

            # Equivalence partitioning recommendations
            if 'amount' in field.field_name.lower() or 'transfer' in field.field_name.lower():
                recommendations['equivalence_tests'].append({
                    'field': field.selector,
                    'field_name': field.field_name,
                    'partition_type': 'transferAmount',
                    'partitions': {
                        'valid': ['small_transfer', 'medium_transfer', 'large_transfer'],
                        'invalid': ['negative_amount', 'zero_amount', 'exceeds_limit']
                    }
                })

            if field.field_type == FieldType.EMAIL:
                recommendations['equivalence_tests'].append({
                    'field': field.selector,
                    'field_name': field.field_name,
                    'partition_type': 'email',
                    'partitions': {
                        'valid': ['standard_email', 'email_with_plus', 'email_with_subdomain'],
                        'invalid': ['missing_at', 'missing_domain', 'invalid_tld']
                    }
                })

        return recommendations


# Singleton instance
script_analyzer = PlaywrightScriptAnalyzer()


# Test function
if __name__ == "__main__":
    # Example Playwright script
    sample_script = """
    import { test, expect } from '@playwright/test';

    test('Bank transfer test', async ({ page }) => {
        await page.goto('https://bank.example.com/transfer');
        await page.fill('#amount', '1000');
        await page.fill('#recipient-email', 'john@example.com');
        await page.fill('#password', 'secret123');
        await page.selectOption('#account-type', 'savings');
        await page.click('#submit-button');
        await expect(page.locator('.success-message')).toBeVisible();
    });
    """

    analyzer = PlaywrightScriptAnalyzer()
    analysis = analyzer.analyze(sample_script)
    recommendations = analyzer.generate_test_data_recommendations(analysis)

    print("=== SCRIPT ANALYSIS ===")
    print(json.dumps(analysis.to_dict(), indent=2))
    print("\n=== TEST DATA RECOMMENDATIONS ===")
    print(json.dumps(recommendations, indent=2))
